#include <fstream>           // {}
#include <iostream>          // {10} cin, get, getline, ws, good, fail, clear, ignore, cout, endl
using std::cin, std::cout;


int main(){

}