#include <string>              // {11} string, at, size, capacity, shrink_to_fit, append, insert, erase, replace, substr, find
#include <iomanip>             // {7}  left, right, setw, setprecision, setfill, boolalpha, noboolalpha 
#include <iostream>            // {8} cin, cout, getline, ws, endl, good, bad, clear
using std::cin, std::cout;

// uncomment whichever test u wanna perf
#define test_1
// #define test_2
// #define test_3
// #define test_4
// #define test_5
// #define test_6


int main()
{
    #ifdef test_1
        std::string str3 {"meow"};
        cout << str3;
    #endif
    
    
    #ifdef test_2
        std::string str {};

        int some;
        std::cin >> some;
        cout << "Enter a string: ";    
        std::getline(std::cin, str);
    #endif


    #ifdef test_3
        std::string str {};
        str = "muhammad Saad 63";

        std::cout << "-> Capacity: " << str.capacity() << "\n-> Length: " << str.size();
        
        str.shrink_to_fit();
        std::cout << "\n\n-> Capacity: " << str.capacity() << "\n-> Length: " << str.size();

        str = "saad";
        std::cout << "\n\n-> Capacity: " << str.capacity() << "\n-> Length: " << str.size();

        cout << "\n\n\n";
        cout << str;
        cout << std::boolalpha;
        cout << '\n' << str.empty();

        str.clear();
        cout << str.empty();
    #endif


    #ifdef test_4
        std::string = {"muhammadSaad63"};
        //cout << str;

        //cout << str.append("! :D");               or += "! :D";
        //cout << str.insert(8, ":) ");
        //cout << (str += " :)");
        //cout << str.replace(0, 8, "I am m").append(". :)");
        //cout << str.erase(0, 2);
        //// can use arithmetic & logic operators like +=, ==, >, <, !=
        cout << str.substr(0, 4);
    #endif


    #ifdef test_5
        std::string str;
        str = "muhammad Saad 63.";

        std::string x = "hammad s";
        cout << ((str.find(x) != std::string::npos)? str.find(x) : false);
    #endif


    #ifdef test_6
        str::string str {};
        cout << "Enter a string: ";    
        std::getline(std::cin >> std::ws, str);

        cout << "\n[Initially]";
        cout << std::left;                                                           // input manipulator; effectively redundant as left-aligned by default
        cout << std::setw(15) << "\n   String: " << str;
        cout << std::setw(15) << "\n   Size: " << str.size();
        cout << std::setw(15) << "\n   Capacity: " << str.capacity();
        cout << std::setw(15) << "\n   IsEmpty?: " << std::boolalpha << str.empty();

        cout << "\n\n";
        for (int i : str){
            cout << (char)(short)i << " ";
        }

        std::string str2 {};
        for (char i : str){
            if (i != ' '){
                str2 += i;
            }
        }

        // removing whitespace
        for (int i = 0; i < str.size(); i++){
            if (str[i] == ' '){                 // or str.at(i)
                str.erase(i, 1);
            }
        }

        cout << "\n\n[Finally]";
        cout << std::setw(15) << "\n   String: " << str;
        cout << std::setw(15) << "\n   Size: " << str.size();
        cout << std::setw(15) << "\n   Capacity: " << str.capacity();
        cout << std::setw(15) << "\n   IsEmpty?: " << std::boolalpha << str.empty();
    #endif
}